clear all; close all;

st_grad_f = load("st_grad.mat");
st_grad = st_grad_f.spatial_temporal_grad;

% Compute image velocities from spatial and temporal gradients
varr = [];
for i=1:size(st_grad,2)
    A = [st_grad(3,i)', st_grad(4,i)'];
    B = st_grad(5,i)';
    v = inv(A'*A)*A'*B;
    v(isinf(v)|isnan(v)) = 0;
    varg = v;
    
    f_obj = @(varg) (norm(A*varg - B))^2;
    disp(f_obj(v));
    options = optimset('algorithm','interior-point');
    [varg,~] = fmincon(f_obj, v, [], [], [], [],...
        [],[],[],options); %find optimal stdev and dvs 
    if norm(varg) > 1
        varr = [varr, [st_grad(1:2,i);normc(varg)*10]];
    else
        varr = [varr, [st_grad(1:2,i);0;0]];
    end
end

% plot optical flow vectors on image
figure(1);
hold on;
myIm = imread("./seq1/sphere4","pgm");
imsurf(myIm,[0,0,0],[0,0,1],[1,0,0],[]);
colormap(gray);
for i=1:size(st_grad,2)
    quiver(varr(2,i),-1*varr(1,i),varr(4,i),-1*varr(3,i));
end
xlim([0, 200]);
ylim([-200, 0]);