function [coeffs] = fit_kernel(image_mats, r_dim, c_dim, center)
    % Given an [r;c;t] center, fit a surface to 5x5 neighborhood
    % Assemble image array of pixels in kernel
    kernel_mat = zeros(r_dim,c_dim,5);
    kernel_arr = zeros(4,r_dim*c_dim*5);
    pixel_ind = 1;
    
    r_ind = 1;
    for r=center(1,1)-floor(r_dim/2):center(1,1)+floor(r_dim/2)
        c_ind = 1;
        for c=center(2,1)-floor(c_dim/2):center(2,1)+floor(c_dim/2)
            t_ind = 1;
            for t=center(3,1)-2:center(3,1)+2
                % matlab indexes photos r:c
                kernel_arr(:,pixel_ind) = image_mats(r,c,t);
                kernel_mat(r_ind, c_ind, t_ind) = image_mats(r,c,t);
                pixel_ind = pixel_ind + 1;
                t_ind = t_ind + 1;
            end
            c_ind = c_ind + 1;
        end
        r_ind = r_ind + 1;
    end
    [D, J] = pixelD(kernel_mat, r_dim, c_dim);
    coeffs_init = inv(D'*D)*D'*J;
    %coeffs = coeffs_init;
    
    % optimize surface to fit images
    options = optimset('algorithm','interior-point','ObjectiveLimit', 6e-02);
    [coeffs,~] = fmincon(@(coeffs)surface_error(coeffs, kernel_arr), coeffs_init, [], [], [], [],...
        [],[],[],options); %find optimal stdev and dvs
end