function [D, J] = pixelD(image_mats, r_dim, c_dim)
    D = zeros(size(image_mats,2)*size(image_mats,1)*size(image_mats,3), 20);
    J = zeros(size(image_mats,2)*size(image_mats,1)*size(image_mats,3), 1);
    pixel_ind = 1;
    for r_l=1:size(image_mats,1)
        for c_l=1:size(image_mats,2)
            for t_l=1:size(image_mats,3)
                J(pixel_ind,1) = image_mats(r_l,c_l,t_l);
                
                % transform coordinate system to center of kernel
                r = r_l-ceil(r_dim/2);
                c = c_l-ceil(c_dim/2);
                t = t_l-3;
                D(pixel_ind,:) = [1,c,r,t,c^2,c*r,r^2,r*t,t^2,c*t,c^3,c^2*r,...
                    c*r^2,r^3,r^2*t,r*t^2,t^3,c^2*t,c*t^2,c*r*t];
                pixel_ind = pixel_ind + 1;
            end
        end
    end
end