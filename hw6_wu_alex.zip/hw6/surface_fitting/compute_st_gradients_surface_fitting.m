clear all; close all;

% load image mats and array
image_mats_f = load("image_mats.mat");
image_mats = image_mats_f.image_mats;
image_arr_f = load("image_arr.mat");
image_arr = image_arr_f.image_arr;

% num pixels on center image
N = size(image_mats,1)*size(image_mats,2);

r_dim = 15;
c_dim = 15;

inc = 14;

% compute spatial and temporal gradients at increments of 14 pixels
spatial_temporal_grad = [];
pixel_count = 0;
for r=ceil(r_dim/2):inc:size(image_mats,1)-floor(r_dim/2)
    for c=ceil(c_dim/2):inc:size(image_mats,2)-floor(c_dim/2)
        coeffs = fit_kernel(image_mats, r_dim, c_dim, [r;c;3]);
        spatial_temporal_grad = [spatial_temporal_grad,[r;c;
            coeffs(2,1);
            coeffs(3,1);
            coeffs(4,1)]];
        disp(pixel_count);
        pixel_count = pixel_count + 1;
    end
end
% save gradients
save("st_grad.mat", "spatial_temporal_grad");