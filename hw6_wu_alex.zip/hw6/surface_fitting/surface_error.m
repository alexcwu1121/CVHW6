function [error] = surface_error(coeffs, xiarr)
    % get a cumulative error between all images
    % xarr is a 4xN matrix [c;r;t;I]
    % coeffs is a 20x1 column vector
    % sum of squared 
    % Objective function for surface fitting
    error = 0;
    for i=1:size(xiarr, 2)
        I_pred = cubic_facet(coeffs, xiarr(1:3,i));
        error = error + (I_pred - xiarr(4,i))^2;
    end
end