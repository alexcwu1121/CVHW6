function [I] = cubic_facet(coeffs, x)
    % solve cubic facet model for some c, r, t and designed coefficients
    % coeffs is a 20x1 column vector
    c = x(1,1);r = x(2,1);t = x(3,1);
    D = [1;c;r;t;
        c^2;c*r;r^2;r*t;t^2;c*t;
        c^3;c^2*r;c*r^2;r^3;r^2*t;r*t^2;t^3;c^2*t;c*t^2;c*r*t];
    I = coeffs'*D;
end