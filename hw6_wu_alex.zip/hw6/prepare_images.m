clear all; close all;

% Read pgm image files into both image matrices and arrays
% Image matrix is rxc
% Image array is 4xN, where each column is [c;r;t;I] and N is the number of
% pixels
image_mats = [];
image_arr = [];
for t=1:5
    image_mats(:,:,t) = imread(append("./seq1/sphere", int2str(t+1)), "pgm");
    imagearr_t = zeros(4, size(image_mats(:,:,t),1)^2);
    ind = 1;
    % try swapping r and c if this doesn't work out
    for r=1:size(image_mats(:,:,t),1)
        for c=1:size(image_mats(:,:,t),2)
            imagearr_t(:,ind) = [r;c;t;image_mats(r,c,t)];
            ind = ind + 1;
        end
    end
    image_arr = [image_arr, imagearr_t];
end

save("image_mats.mat", "image_mats");
save("image_arr.mat", "image_arr");