clear all; close all;

st_grad_f = load("st_grad.mat");
st_grad = st_grad_f.st_grads;
st_grad_mat_f = load("st_grad_mat.mat");
st_grad_mat = st_grad_mat_f.st_grads_mat;

% optical flow estimation neighborhood size
N = 31;

% for a every pixel in a downsampled image, compute velocity field in a
% neighborhood
varr = zeros(4,size(st_grad_mat_f,1)^2);
num_pixels = 1;
for r=ceil(N/2):10:size(st_grad_mat,1) - floor(N/2)
    for c=ceil(N/2):10:size(st_grad_mat,2) - floor(N/2)
        % spatial intensity grads
        A = zeros(N,2);
        % temporal intensity grads
        B = zeros(N,1);
        pixel_ind = 1;
        for r_i = r-floor(N/2):r+floor(N/2)
            for c_i = c-floor(N/2):c+floor(N/2)
                A(pixel_ind, :) = [st_grad_mat(r_i,c_i,1), st_grad_mat(r_i,c_i,2)];
                B(pixel_ind, :) = -1*st_grad_mat(r_i,c_i,3);
                pixel_ind = pixel_ind + 1;
            end
        end
        
        v = inv(A'*A)*A'*B;
        v(isinf(v)|isnan(v)) = 0;
        varr(:,num_pixels) = [r;c;v];
        
        num_pixels = num_pixels + 1;
    end
end
varr = varr(:,1:num_pixels-1);
varr(3:4,:) = varr(3:4,:)*10;

% save velocity field
save("varr.mat", "varr");

% plot a downsample of optical flow vectors on image
figure(1);
hold on;
myIm = imread("../seq1/sphere4","pgm");
imsurf(myIm,[0,0,0],[0,0,1],[1,0,0],[]);
colormap(gray);
for i=1:size(varr,2)
    quiver(varr(2,i),-1*varr(1,i),varr(4,i),-1*varr(3,i));
end
xlim([0, 200]);
ylim([-200, 0]);