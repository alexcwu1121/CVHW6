clear all; close all;
% Derive 3D velocity vectors from 2D image vectors using assumptions about
% the object

% Rotating sphere
% No translational motion. Only rotational motion and axis is unknown
% Radius of sphere unknown
% Intrinsic camera parameters unknown

varr_f = load("varr");
varr = varr_f.varr;

% Assuming values for camera intrinsic parameters, the motion field
% equations provide 2 equations per pixel and there are 3 unknowns (three
% rotational velocities)
% Assume the principal point is 100,100: the center of the image
r0 = 100;
c0 = 100;
f = 100;
sx = 1;
sy = 1;

% Use a simple linear regression to solve for components of rotation
% Where A = [f*sy+(r-r0)^2/(f*sy), -1*(c-c0)*(r-r0)/(f*sx), -1*(c-c0)*sy/sx;
%            (c-c0)*(r-r0)/(f*sy), -1*f*sx-(c-c0)^2/(f*sx), (r-r0)*sx/sy];
% Where B = [vr;vc];
% A is 2*N x 3
% w is 3 x 1
% B is 2*N x 1
A = zeros(2*size(varr,2), 3);
B = zeros(2*size(varr,2), 1);
for pixel=1:size(varr,2)
    r = varr(1,pixel);
    c = varr(2,pixel);
    A_p = [f*sy+(r-r0)^2/(f*sy), -1*(c-c0)*(r-r0)/(f*sx), -1*(c-c0)*sy/sx;
        (c-c0)*(r-r0)/(f*sy), -1*f*sx-(c-c0)^2/(f*sx), (r-r0)*sx/sy];
    B_p = [varr(3,pixel);varr(4,pixel)];
    A(2*pixel-1:2*pixel,:) = A_p;
    B(2*pixel-1:2*pixel,:) = B_p;
end
w = inv(A'*A)*A'*B;
w(isinf(w)|isnan(w)) = 0;

disp(w);