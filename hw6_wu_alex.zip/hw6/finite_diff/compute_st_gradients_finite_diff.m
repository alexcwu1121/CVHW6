clear all; close all;

% load image mats and array
image_mats_f = load("image_mats.mat");
image_mats = image_mats_f.image_mats;
image_arr_f = load("image_arr.mat");
image_arr = image_arr_f.image_arr;

% smooth images using 5x5 mean kernel
for t = 1:size(image_mats,3)
    image_mats_smooth(:,:,t) = mean_smooth(image_mats(:,:,t),5);
end

% Compare smooth and nonsmooth images
figure(1);
imsurf(image_mats(:,:,1),[0,0,0],[0,0,1],[1,0,0],[]);
colormap(gray);
figure(2);
imsurf(image_mats_smooth(:,:,1),[0,0,0],[0,0,1],[1,0,0],[]);
colormap(gray);

% Calculate spatial and temporal gradients at each pixel in center frame
% with finite difference
st_grads_mat = zeros(size(image_mats,1),size(image_mats,2),3);
st_grads = zeros(5,size(image_mats,1)^2);
pixel_ind = 1;
for r=2:size(image_mats,1)-1
    for c=2:size(image_mats,2)-1
        st_grad = finite_diff(image_mats_smooth, [r;c;3]);
        st_grads(:,pixel_ind) = [r;c;st_grad];
        
        st_grads_mat(r,c,1) = st_grad(1,1);
        st_grads_mat(r,c,2) = st_grad(2,1);
        st_grads_mat(r,c,3) = st_grad(3,1);
        
        pixel_ind = pixel_ind + 1;
    end
end
save("st_grad_mat.mat", "st_grads_mat");
save("st_grad.mat", "st_grads");