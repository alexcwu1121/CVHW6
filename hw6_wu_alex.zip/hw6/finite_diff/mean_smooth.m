function [image_smooth] = mean_smooth(image, kernel_size)
    image_smooth = zeros(size(image));
    for r=ceil(kernel_size/2):size(image,1) - floor(kernel_size/2)
        for c=ceil(kernel_size/2):size(image,2) - floor(kernel_size/2)
            sum = 0;
            for r_i = r-floor(kernel_size/2):r+floor(kernel_size/2)
                for c_i = c-floor(kernel_size/2):c+floor(kernel_size/2)
                    sum = sum + image(r_i, c_i);
                end
            end
            image_smooth(r,c) = sum/kernel_size^2;
        end
    end
end