function [st_grad] = finite_diff(I, pixel)
    % pixel is [r;c;t]
    % compute x diff, y diff, z diff using simple single difference method
    Ir = I(pixel(1,1), pixel(2,1), pixel(3,1)) -...
        I(pixel(1,1) - 1, pixel(2,1), pixel(3,1));
    Ic = I(pixel(1,1), pixel(2,1), pixel(3,1)) -...
        I(pixel(1,1), pixel(2,1) - 1, pixel(3,1));
    It = I(pixel(1,1), pixel(2,1), pixel(3,1)) -...
        I(pixel(1,1), pixel(2,1), pixel(3,1) - 1);
    
    st_grad = [Ir;Ic;It];
end